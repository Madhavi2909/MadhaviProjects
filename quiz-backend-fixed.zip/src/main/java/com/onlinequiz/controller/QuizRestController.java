package com.onlinequiz.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.onlinequiz.service.*;
import com.onlinequiz.repository.*;
import com.onlinequiz.model.*;
import java.util.*;

@RestController
@RequestMapping("/api")
public class QuizRestController {
    @Autowired private QuizService quizService;
    @Autowired private AttemptService attemptService;
    @Autowired private UserRepository userRepository;
    @Autowired private AttemptRepository attemptRepository;

    @GetMapping("/quizzes")
    public List<Quiz> allQuizzes(){ return quizService.all(); }

    @GetMapping("/quizzes/{id}")
    public Quiz getQuiz(@PathVariable Long id){ return quizService.find(id); }

    @PostMapping("/quizzes/{id}/start")
    public Map<String,Object> start(@PathVariable Long id, @RequestParam Long userId){
        UserAccount user = userRepository.findById(userId).orElseThrow();
        Attempt a = attemptService.startAttempt(user, id);
        Map<String,Object> res = new HashMap<>();
        res.put("attemptId", a.getId());
        res.put("startTime", a.getStartTime());
        res.put("deadline", a.getStartTime().plusMinutes(a.getQuiz().getDurationMinutes()));
        return res;
    }

    @PostMapping("/attempts/{attemptId}/submit")
    public Attempt submit(@PathVariable Long attemptId, @RequestBody List<Answer> answers){
        return attemptService.submitAttempt(attemptId, answers);
    }

    @GetMapping("/attempts/{id}")
    public Attempt getAttempt(@PathVariable Long id){
        Attempt a = attemptRepository.findById(id).orElseThrow();
        attemptService.autoSubmitIfTimeout(a);
        return a;
    }
}

package com.onlinequiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.onlinequiz.model.Attempt;

public interface AttemptRepository extends JpaRepository<Attempt, Long> {}

package com.onlinequiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.onlinequiz.model.Question;

public interface QuestionRepository extends JpaRepository<Question, Long> {}

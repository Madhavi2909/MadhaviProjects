package com.onlinequiz.model;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Attempt {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private UserAccount user;

    @ManyToOne
    private Quiz quiz;

    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private double totalScore;
    private boolean finished = false;

    @OneToMany(mappedBy = "attempt", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Answer> answers;

    public Attempt() {}
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public UserAccount getUser(){return user;}
    public void setUser(UserAccount u){this.user=u;}
    public Quiz getQuiz(){return quiz;}
    public void setQuiz(Quiz q){this.quiz=q;}
    public LocalDateTime getStartTime(){return startTime;}
    public void setStartTime(LocalDateTime s){this.startTime=s;}
    public LocalDateTime getEndTime(){return endTime;}
    public void setEndTime(LocalDateTime e){this.endTime=e;}
    public double getTotalScore(){return totalScore;}
    public void setTotalScore(double t){this.totalScore=t;}
    public boolean isFinished(){return finished;}
    public void setFinished(boolean f){this.finished=f;}
    public java.util.List<Answer> getAnswers(){return answers;}
    public void setAnswers(java.util.List<Answer> a){this.answers=a;}
}

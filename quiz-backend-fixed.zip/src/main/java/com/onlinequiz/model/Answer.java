package com.onlinequiz.model;

import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Answer {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JsonBackReference
    private Attempt attempt;

    @ManyToOne
    private Question question;

    @ManyToOne
    private OptionItem selectedOption;

    @Column(columnDefinition = "TEXT")
    private String textAnswer;

    private Boolean isCorrect;
    private double marksObtained;

    public Answer() {}
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Attempt getAttempt(){return attempt;}
    public void setAttempt(Attempt a){this.attempt=a;}
    public Question getQuestion(){return question;}
    public void setQuestion(Question q){this.question=q;}
    public OptionItem getSelectedOption(){return selectedOption;}
    public void setSelectedOption(OptionItem o){this.selectedOption=o;}
    public String getTextAnswer(){return textAnswer;}
    public void setTextAnswer(String t){this.textAnswer=t;}
    public Boolean getIsCorrect(){return isCorrect;}
    public void setIsCorrect(Boolean c){this.isCorrect=c;}
    public double getMarksObtained(){return marksObtained;}
    public void setMarksObtained(double m){this.marksObtained=m;}
}

package com.onlinequiz.model;

import javax.persistence.*;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Question {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "quiz_id")
    @JsonBackReference
    private Quiz quiz;

    @Column(columnDefinition = "TEXT")
    private String text;

    @Enumerated(EnumType.STRING)
    private QuestionType type;

    private int marks = 1;

    @OneToMany(mappedBy = "question", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<OptionItem> options;

    public Question() {}
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Quiz getQuiz(){return quiz;}
    public void setQuiz(Quiz q){this.quiz=q;}
    public String getText(){return text;}
    public void setText(String t){this.text=t;}
    public QuestionType getType(){return type;}
    public void setType(QuestionType t){this.type=t;}
    public int getMarks(){return marks;}
    public void setMarks(int m){this.marks=m;}
    public List<OptionItem> getOptions(){return options;}
    public void setOptions(List<OptionItem> o){this.options=o;}
}

package com.onlinequiz.model;
public enum QuestionType {
    MCQ, TRUE_FALSE, SHORT_ANSWER
}

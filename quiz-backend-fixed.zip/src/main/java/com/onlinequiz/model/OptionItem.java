package com.onlinequiz.model;

import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class OptionItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "question_id")
    @JsonBackReference
    private Question question;

    @Column(length=1000)
    private String text;

    private boolean isCorrect;

    public OptionItem() {}
    public OptionItem(Question question, String text, boolean isCorrect){
        this.question = question; this.text = text; this.isCorrect = isCorrect;
    }
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Question getQuestion(){return question;}
    public void setQuestion(Question q){this.question=q;}
    public String getText(){return text;}
    public void setText(String t){this.text=t;}
    public boolean isCorrect(){return isCorrect;}
    public void setCorrect(boolean c){this.isCorrect=c;}
}

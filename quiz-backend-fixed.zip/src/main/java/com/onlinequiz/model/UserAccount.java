package com.onlinequiz.model;

import javax.persistence.*;

@Entity
@Table(name = "user_account")
public class UserAccount {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique=true, nullable=false)
    private String username;
    @Column(nullable=false)
    private String password;
    private String fullname;
    private String role = "USER";

    public UserAccount() {}
    public UserAccount(String username, String password, String fullname){
        this.username = username; this.password = password; this.fullname = fullname;
    }
    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id = id;}
    public String getUsername(){return username;}
    public void setUsername(String u){this.username=u;}
    public String getPassword(){return password;}
    public void setPassword(String p){this.password=p;}
    public String getFullname(){return fullname;}
    public void setFullname(String f){this.fullname=f;}
    public String getRole(){return role;}
    public void setRole(String r){this.role=r;}
}

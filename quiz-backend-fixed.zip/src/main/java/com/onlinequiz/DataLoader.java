package com.onlinequiz;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import com.onlinequiz.repository.*;
import com.onlinequiz.model.*;

@Component
public class DataLoader implements CommandLineRunner {
    @Autowired private QuizRepository quizRepository;
    @Autowired private QuestionRepository questionRepository;
    @Autowired private OptionRepository optionRepository;
    @Autowired private UserRepository userRepository;

    @Override
    public void run(String... args) throws Exception {
        if(quizRepository.count() == 0){
            UserAccount u = new UserAccount("user1","password","User One");
            userRepository.save(u);

            Quiz q = new Quiz();
            q.setTitle("General Knowledge");
            q.setDescription("Short sample quiz");
            q.setDurationMinutes(1); // 1 minute for demo
            quizRepository.save(q);

            Question qq = new Question();
            qq.setQuiz(q); qq.setText("What is 2+2?"); qq.setType(QuestionType.MCQ); qq.setMarks(1);
            questionRepository.save(qq);

            optionRepository.save(new OptionItem(qq, "3", false));
            optionRepository.save(new OptionItem(qq, "4", true));
            option_repository_save(optionRepository, new OptionItem(qq, "5", false));

            Question tf = new Question();
            tf.setQuiz(q); tf.setText("Earth is round?"); tf.setType(QuestionType.TRUE_FALSE); tf.setMarks(1);
            questionRepository.save(tf);
            optionRepository.save(new OptionItem(tf, "True", true));
            optionRepository.save(new OptionItem(tf, "False", false));

            Question sa = new Question();
            sa.setQuiz(q); sa.setText("Name a primary color"); sa.setType(QuestionType.SHORT_ANSWER); sa.setMarks(1);
            questionRepository.save(sa);
            optionRepository.save(new OptionItem(sa, "red", true));
            option_repository_save(optionRepository, new OptionItem(sa, "blue", true));
            option_repository_save(optionRepository, new OptionItem(sa, "yellow", true));

            // second quiz
            Quiz q2 = new Quiz();
            q2.setTitle("Math Basics");
            q2.setDescription("Simple math quiz");
            q2.setDurationMinutes(2);
            quizRepository.save(q2);

            Question m1 = new Question(); m1.setQuiz(q2); m1.setText("What is 10/2?"); m1.setType(QuestionType.MCQ); m1.setMarks(1);
            questionRepository.save(m1);
            option_repository_save(optionRepository, new OptionItem(m1, "4", false));
            option_repository_save(optionRepository, new OptionItem(m1, "5", true));
            option_repository_save(optionRepository, new OptionItem(m1, "6", false));
        }
    }

    // helper method because JPA save needs repo instance
    private void option_repository_save(OptionRepository repo, OptionItem item){
        repo.save(item);
    }
}

package com.onlinequiz.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.onlinequiz.repository.*;
import com.onlinequiz.model.*;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class AttemptService {
    @Autowired
    private AttemptRepository attemptRepository;
    @Autowired
    private QuizRepository quizRepository;
    @Autowired
    private AnswerRepository answerRepository;
    @Autowired
    private OptionRepository optionRepository;
    @Autowired
    private QuestionRepository questionRepository;

    public Attempt startAttempt(UserAccount user, Long quizId){
        Quiz q = quizRepository.findById(quizId).orElseThrow();
        Attempt a = new Attempt();
        a.setUser(user);
        a.setQuiz(q);
        a.setStartTime(LocalDateTime.now());
        a.setFinished(false);
        return attemptRepository.save(a);
    }

    public Attempt submitAttempt(Long attemptId, List<Answer> answersFromClient){
        Attempt attempt = attemptRepository.findById(attemptId).orElseThrow();
        if(attempt.isFinished()) return attempt;
        double total = 0.0;
        for(Answer given : answersFromClient){
            Question question = questionRepository.findById(given.getQuestion().getId()).orElseThrow();
            Answer newAns = new Answer();
            newAns.setAttempt(attempt);
            newAns.setQuestion(question);

            if(question.getType() == QuestionType.MCQ || question.getType() == QuestionType.TRUE_FALSE){
                Long selOptId = given.getSelectedOption() != null ? given.getSelectedOption().getId() : null;
                if(selOptId != null){
                    OptionItem sel = optionRepository.findById(selOptId).orElse(null);
                    newAns.setSelectedOption(sel);
                    boolean correct = sel != null && sel.isCorrect();
                    newAns.setIsCorrect(correct);
                    if(correct) newAns.setMarksObtained(question.getMarks());
                }
            } else {
                newAns.setTextAnswer(given.getTextAnswer());
                boolean correct = false;
                if(question.getOptions() != null){
                    for(OptionItem opt : question.getOptions()){
                        if(opt.isCorrect() && opt.getText().trim().equalsIgnoreCase(given.getTextAnswer() == null ? "" : given.getTextAnswer().trim())){
                            correct = true; break;
                        }
                    }
                }
                newAns.setIsCorrect(correct);
                if(correct) newAns.setMarksObtained(question.getMarks());
            }

            answerRepository.save(newAns);
            total += newAns.getMarksObtained();
        }

        attempt.setTotalScore(total);
        attempt.setEndTime(LocalDateTime.now());
        attempt.setFinished(true);
        attemptRepository.save(attempt);
        return attempt;
    }

    public void autoSubmitIfTimeout(Attempt attempt){
        if(attempt.isFinished()) return;
        LocalDateTime deadline = attempt.getStartTime().plusMinutes(attempt.getQuiz().getDurationMinutes());
        if(LocalDateTime.now().isAfter(deadline)){
            attempt.setFinished(true);
            attempt.setEndTime(deadline);
            attemptRepository.save(attempt);
        }
    }
}

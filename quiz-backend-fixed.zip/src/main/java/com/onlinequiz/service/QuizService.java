package com.onlinequiz.service;

import org.springframework.stereotype.Service;
import com.onlinequiz.repository.QuizRepository;
import com.onlinequiz.model.Quiz;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class QuizService {
    @Autowired
    private QuizRepository quizRepository;

    public List<Quiz> all(){ return quizRepository.findAll(); }
    public Quiz find(Long id){ return quizRepository.findById(id).orElse(null); }
    public Quiz save(Quiz q){ return quizRepository.save(q); }
}

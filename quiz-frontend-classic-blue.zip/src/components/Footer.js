
import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <p className="mb-0">&copy; 2025 Online Quiz Portal. All rights reserved.</p>
      </div>
    </footer>
  );
}

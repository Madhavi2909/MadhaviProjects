
import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

export default function QuizPage() {
  const { id } = useParams();
  const [quiz, setQuiz] = useState(null);
  const [attemptId, setAttemptId] = useState(null);
  const [answers, setAnswers] = useState({});
  const [deadline, setDeadline] = useState(null);
  const [timeLeft, setTimeLeft] = useState(null);
  const timerRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:8080/api/quizzes/' + id)
      .then(r => r.json())
      .then(setQuiz);
  }, [id]);

  useEffect(() => {
    if (deadline) {
      timerRef.current = setInterval(() => {
        const diff = new Date(deadline) - new Date();
        if (diff <= 0) {
          clearInterval(timerRef.current);
          submitQuiz();
          return;
        }
        const mins = Math.floor(diff / 60000);
        const secs = Math.floor((diff % 60000) / 1000);
        setTimeLeft(mins + ':' + (secs < 10 ? '0' + secs : secs));
      }, 300);
      return () => clearInterval(timerRef.current);
    }
  }, [deadline]);

  function startQuiz() {
    fetch('http://localhost:8080/api/quizzes/' + id + '/start?userId=1', { method: 'POST' })
      .then(r => r.json())
      .then(data => {
        setAttemptId(data.attemptId);
        setDeadline(data.deadline);
      });
  }

  function handleSelect(qid, optId) {
    setAnswers(prev => ({ ...prev, [qid]: { selectedOption: optId } }));
  }

  function handleText(qid, text) {
    setAnswers(prev => ({ ...prev, [qid]: { textAnswer: text } }));
  }

  function submitQuiz() {
    if (!attemptId) return;
    const payload = Object.keys(answers).map(k => {
      const qid = parseInt(k);
      const item = answers[k];
      const obj = { question: { id: qid } };
      if (item.selectedOption) obj.selectedOption = { id: item.selectedOption };
      if (item.textAnswer) obj.textAnswer = item.textAnswer;
      return obj;
    });
    fetch('http://localhost:8080/api/attempts/' + attemptId + '/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(r => r.json())
      .then(res => {
        alert('Your score: ' + res.totalScore);
        navigate('/');
      });
  }

  if (!quiz) return <div className="container my-5">Loading...</div>;

  return (
    <div className="container my-5">
      <h2 className="text-primary">{quiz.title}</h2>
      <p>{quiz.description}</p>
      <p>Duration: {quiz.durationMinutes} minutes {deadline && <span className="badge bg-primary timer ms-2">⏱ {timeLeft}</span>}</p>
      {!attemptId ? (
        <button className="btn btn-success" onClick={startQuiz}>Start Quiz</button>
      ) : (
        <div className="mt-4">
          {quiz.questions.map(q => (
            <div className="mb-4" key={q.id}>
              <p><strong>{q.text}</strong></p>
              {(q.type === 'MCQ' || q.type === 'TRUE_FALSE') ? (
                q.options.map(opt => (
                  <div className="form-check" key={opt.id}>
                    <input className="form-check-input" type="radio" name={'q' + q.id} id={'q' + q.id + 'o' + opt.id} onChange={() => handleSelect(q.id, opt.id)} />
                    <label className="form-check-label" htmlFor={'q' + q.id + 'o' + opt.id}>{opt.text}</label>
                  </div>
                ))
              ) : (
                <textarea className="form-control" rows="2" onChange={(e) => handleText(q.id, e.target.value)}></textarea>
              )}
            </div>
          ))}
          <button className="btn btn-primary" onClick={submitQuiz}>Submit</button>
        </div>
      )}
    </div>
  );
}

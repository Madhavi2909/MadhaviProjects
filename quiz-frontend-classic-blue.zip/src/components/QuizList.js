
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function QuizList() {
  const [quizzes, setQuizzes] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8080/api/quizzes')
      .then(res => res.json())
      .then(setQuizzes)
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      <div className="hero">
        <div className="container">
          <h1 className="display-5 fw-bold">Online Quiz Portal</h1>
          <p className="lead">Test your knowledge and boost your skills!</p>
        </div>
      </div>
      <div className="container my-5">
        <h2 className="mb-4 text-primary">Available Quizzes</h2>
        <div className="row g-4">
          {quizzes.map(q => (
            <div className="col-md-6 col-lg-4" key={q.id}>
              <div className="card card-quiz h-100">
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title text-primary">{q.title}</h5>
                  <p className="card-text flex-grow-1">{q.description}</p>
                  <Link to={'/quiz/' + q.id} className="btn btn-primary mt-2">Take Quiz</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

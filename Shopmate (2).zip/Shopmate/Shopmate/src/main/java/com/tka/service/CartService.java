package com.tka.service;


import java.util.List;

import javax.servlet.http.HttpSession;

import com.tka.modelentity.ProductDTO;

public interface CartService {
    void addToCart(ProductDTO product);
    void removeFromCart(int productId);
    List<ProductDTO> getCartItems();
    void clearCart();
	Object getTotalAmount();
}

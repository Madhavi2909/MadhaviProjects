package com.tka;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.tka.modelentity.Product;
import com.tka.service.ProductService;

@Controller
public class AmzController {
	@Autowired
	ProductService productService;

	@GetMapping("/")
	public String getHomePage(Model model) {
		List<Product> productList = productService.getAllProduct();
		model.addAttribute("products", productList);
		return "index";
	}

	@GetMapping("/index")
	public String getIndexPage(Model model) {
		List<Product> productList = productService.getAllProduct();
		System.out.println(productList);
		model.addAttribute("products", productList);
		return "index";
	}

	@GetMapping("/login")
	public String getLoginPage() {
		return "login";
	}

	@GetMapping("/signup")
	public String getSignUpPage() {
		return "signup";
	}

	@GetMapping("/get-addProductPage")
	public String getAddProductPage() {
		return "addproduct"; // .jsp
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		// ✅ Invalidate session
		session.invalidate();

		// Redirect to logout.jsp page
		return "logout";
	}

}
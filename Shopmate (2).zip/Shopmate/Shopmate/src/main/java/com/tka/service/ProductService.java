package com.tka.service;

import com.tka.modelentity.Product;

import java.util.List;

import org.springframework.stereotype.Service;


@Service
public interface ProductService {

    String addProduct(Product Product);
    String updateProduct(Product Product);
    String deleteProduct(Product Product);
    Product getProduct(int id);
     List<Product> getAllProduct();
	Product getProductById(int productId);
}


package com.tka;
import com.tka.modelentity.Customer;
import com.tka.modelentity.Product;
import com.tka.modelentity.ProductDTO;
import com.tka.service.CartService;
import com.tka.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

@Controller
public class ShopController {

    @Autowired
    private ProductService productService;

    @Autowired
    private CartService cartService;

    // ---------------- SHOPPING ----------------
    @GetMapping("/shopping")
    public String viewProducts(Model model) {
        List<ProductDTO> products = productService.getAllProduct()
                .stream()
                .map(p -> new ProductDTO(
                        p.getProductId(),
                        p.getProductName(),
                        p.getPrice(),
                        p.getDescription(),
                        p.getQuantity(),
                        p.getImageUrl()
                ))
                .collect(Collectors.toList());

        model.addAttribute("products", products);
        return "shopping"; // JSP name
    }

    // ---------------- ADD TO CART ----------------
   /* @PostMapping("/cart/add")
    public String addToCart(@RequestParam int productId) {
        Product product = productService.getProductById(productId);
        if (product != null) {
            ProductDTO dto = new ProductDTO(
                    product.getProductId(),
                    product.getProductName(),
                    product.getPrice(),
                    product.getDescription(),
                    product.getQuantity(),
                    product.getImageUrl()
            );
            cartService.addToCart(dto);
        }
        return "redirect:/cart";
    }*/
    
    @PostMapping("/cart/add")
    public String addToCart(@RequestParam int productId, HttpSession session, Model model) {
        // ✅ Check if user is logged in
        Object user = session.getAttribute("loggedInUser");
        if (user == null) {
            model.addAttribute("error", "Please login first to add products to your cart.");
            return "login"; // go to login.jsp (or your login page mapping)
        }

        // ✅ User is logged in → proceed with adding to cart
        Product product = productService.getProductById(productId);
        if (product != null) {
            ProductDTO dto = new ProductDTO(
                    product.getProductId(),
                    product.getProductName(),
                    product.getPrice(),
                    product.getDescription(),
                    product.getQuantity(),
                    product.getImageUrl()
            );
            cartService.addToCart(dto);
        }

        return "redirect:/cart";
    }



    // ---------------- VIEW CART ----------------
    @GetMapping("/cart")
    public String viewCart(Model model) {
        model.addAttribute("cartItems", cartService.getCartItems());
        model.addAttribute("totalAmount", cartService.getTotalAmount());
        return "cart"; // JSP name
    }

    // ---------------- REMOVE FROM CART ----------------
    @PostMapping("/cart/remove")
    public String removeFromCart(@RequestParam int productId) {
        cartService.removeFromCart(productId);
        return "redirect:/cart";
    }

    // ---------------- BILL / CHECKOUT ----------------
    @GetMapping("/bill")
    public String bill(Model model, HttpSession session) {
        Customer customer = (Customer) session.getAttribute("loggedInCustomer");

        if (customer != null) {
            return"bill"; // force login if not logged in
        }
       
        model.addAttribute("cartItems", cartService.getCartItems());
        model.addAttribute("totalAmount", cartService.getTotalAmount());
        model.addAttribute("customer", customer); // ✅ add customer object

        return "bill";
    }
   


    }
  
    


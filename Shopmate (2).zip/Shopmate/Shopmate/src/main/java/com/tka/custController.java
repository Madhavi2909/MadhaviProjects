package com.tka;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tka.modelentity.Customer;
import com.tka.service.CustomerService;

@Controller
public class custController {
	@Autowired
	CustomerService customerService;

	String msg;
	
	
  /*  @PostMapping("/verify-login")
	public String verifyLogin(@ModelAttribute Customer customer,Model model) {
	    System.out.println("verify code");
	    msg = "Login Successfully....";  
	    model.addAttribute("msg", msg);
	    return "index";
	}*/
	@PostMapping("/register")
	public String registerCustomer(@ModelAttribute Customer customer, Model model) {
	    String msg = "Register Successfully....";
	    // db code
	    msg = customerService.insertCustomer(customer);
	    model.addAttribute("msg", msg);
	    List<Customer> customerList = customerService.getAllCustomer();
	    model.addAttribute("customerList", customerList);
	    return "allCustomerDetails";
	}
	
	@GetMapping("/view-customer")
	public String getAllCustomer(@ModelAttribute Customer customer, Model model) {
	    List<Customer> customerList = customerService.getAllCustomer();
	    model.addAttribute("customerList", customerList);
	    return "allCustomerDetails"; // .jsp
	}

	
	@PostMapping("/verify-login")
	public String verifyLogin(@RequestParam String email,
	                          @RequestParam String password,
	                          HttpSession session,
	                          Model model) {

	    // Check credentials from DB
	    Customer customer = customerService.findByEmailAndPassword(email, password);

	    if (customer != null) {
	        // ✅ store user in session
	        session.setAttribute("loggedInUser", customer);

	        // redirect to home page
	        return "redirect:/shopping";
	    } else {
	        // add error to show in login.jsp
	        model.addAttribute("error", "Invalid email or password!");
	        return "login";
	    }
	}
	

	
	}

	



	

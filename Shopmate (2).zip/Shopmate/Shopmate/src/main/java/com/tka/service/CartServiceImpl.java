package com.tka.service;

import org.springframework.stereotype.Service;

import com.tka.modelentity.ProductDTO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    private final List<ProductDTO> cartItems = new ArrayList<>();

    @Override
    public void addToCart(ProductDTO product) {
        cartItems.add(product);
    }

    @Override
    public void removeFromCart(int productId) {
        Iterator<ProductDTO> iterator = cartItems.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getProductId() == productId) {
                iterator.remove();
                break;
            }
        }
    }

    @Override
    public List<ProductDTO> getCartItems() {
        return new ArrayList<>(cartItems);
    }

  

    @Override
    public void clearCart() {
        cartItems.clear();
    }

	@Override
	public Object getTotalAmount() {
		 return cartItems.stream()
	                .mapToDouble(p -> p.getPrice() * (p.getQuantity() == 0 ? 1 : p.getQuantity()))
	                .sum();
	}
}

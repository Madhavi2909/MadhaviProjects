package com.tka.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.dao.CustomerDaoJPA;
import com.tka.modelentity.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
    CustomerDaoJPA dao;
    
    @Override
    public String insertCustomer(Customer customer) {
		dao.save(customer);
        return customer.getFullName()+ " >Inserted Successfully....";
    }
	@Override
	public void updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean getCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}
   
		
	
    @Override
    public List<Customer> getAllCustomer() {
        return dao.findAll();
    }
    

	
	 @Override
	    public void deleteCustomer(int cid) {
	        // code here
	    }
	@Override
	public Customer findByEmailAndPassword(String email, String password) {
		return dao.findByEmailAndPassword(email,password);
	}
	
	
	
	

	
}

package com.tka.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tka.modelentity.Customer;
@Service
public interface CustomerService {

	String insertCustomer(Customer customer);
    void updateCustomer(Customer customer);
    void deleteCustomer(int cid);
    boolean getCustomer(Customer customer);
    List<Customer> getAllCustomer();
	Customer findByEmailAndPassword(String email, String password);
}

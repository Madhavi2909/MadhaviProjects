package com.tka.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.dao.ProductDaoJPA;
import com.tka.modelentity.Product;


@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDaoJPA dao;
	

	@Override
	public String addProduct(Product product) {
		Product saveProduct = dao.save(product);
		if (saveProduct != null)
			return product.getProductName() + " successfully added ";
		else
			return product.getProductName() + " failed to add product ";

	}
	

	@Override
	public String updateProduct(Product product) {
		dao.save(product);
		Product updateProduct = dao.save(product);
		if (updateProduct != null)
			return product.getProductName() + " successfully updated ";
		else
			return product.getProductName() + " failed to update product ";

	}
	

	@Override
	public String deleteProduct(Product product) {
		 dao.delete(product);
		return "product";
	}
	@Override
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProduct() {
		return dao.findAll();
	}

	@Override
	public Product getProductById(int productId) {
		System.err.println("in > service ..getProductById ");
		return dao.getById(productId);

	}

}
